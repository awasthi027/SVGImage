//
//  ContentView.swift
//  SVGImage
//
//  Created by Tanuja Awasthi on 02/09/23.
//

import SwiftUI

struct ContentView: View {
    @State var image: UIImage = UIImage()
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
            SVGImage(url: "https://windaddy-resources.s3.ap-south-1.amazonaws.com/resources/ab/89/f448-826c-4a6f-95c5-a55ff98b0c1f/livecasino.svg".asUrl)
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// MARK: Convert Strings
extension String {
    /// convert string in http url
    public var asUrl: URL {
        let urlStr = self.replacingOccurrences(of: " ", with: "%20")
        guard let url = URL(string: urlStr) else {
            return URL.init(fileURLWithPath:  "")
        }
        return url
    }
}
