//
//  SVGImageApp.swift
//  SVGImage
//
//  Created by Tanuja Awasthi on 02/09/23.
//

import SwiftUI

@main
struct SVGImageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
